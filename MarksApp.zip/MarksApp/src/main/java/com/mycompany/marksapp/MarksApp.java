
package com.mycompany.marksapp;
import javax.swing.*;

public class MarksApp {

    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog("Enter your mark");
        int mark = Integer.parseInt(input); //Changed string input to integer
        
        if(mark >= 50 && mark <= 100){
            JOptionPane.showMessageDialog( null,"You Passed");
        }
        else{
            JOptionPane.showMessageDialog(null, "You Failed");
        }
        
        if(mark > 100 || mark < 0){
            JOptionPane.showMessageDialog(null, "invalid mark");
        }
        
        
        
    }
}
